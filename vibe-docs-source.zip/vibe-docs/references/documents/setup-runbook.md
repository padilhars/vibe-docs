# Setup & Runbook — Ambiente e Operação

## Propósito
Reunir tudo que alguém (ou um agente) precisa pra sair de um repositório recém-clonado até o sistema rodando e os testes passando. É o documento que alimenta a seção de Comandos do `CLAUDE.md` — sem ele, um agente autônomo não consegue nem verificar se o que escreveu funciona.

## Insumos necessários do Blueprint
Arquitetura (stack, componentes, persistência), integrações externas (para saber quais credenciais são necessárias), Test Strategy (para o comando de teste). Se a stack ainda não foi decidida, este documento não deve ser gerado ainda — não há comando real a documentar, e inventar um genérico é pior que não ter.

## Estrutura obrigatória

```markdown
# Setup & Runbook — [Nome do Projeto]

## Pré-requisitos
[runtime e versão, banco de dados, ferramentas externas necessárias antes de qualquer coisa]

## Instalação
```
[passo a passo, em comandos executáveis]
```

## Variáveis de Ambiente

| Variável | Obrigatória | Descrição | Exemplo (nunca um valor real) |
|---|---|---|---|

## Comandos do Dia a Dia

| Ação | Comando |
|---|---|
| Rodar em desenvolvimento | |
| Rodar todos os testes | |
| Rodar um teste específico | |
| Lint / formatação | |
| Migrations | |
| Build de produção | |

## Estrutura de Pastas
[o mapa do repositório, com uma linha sobre o que vive em cada pasta principal — é o que evita um agente criar arquivo no lugar errado]

## Dados Iniciais
[como popular o banco pra desenvolvimento — seeds, fixtures, usuário admin inicial]

## Problemas Conhecidos
[armadilhas de ambiente já identificadas, se houver — porta ocupada, dependência de sistema, passo que falha silenciosamente]
```

## Regras específicas

- **Nunca escreva credencial, chave ou senha real neste documento**, nem como exemplo. A coluna de exemplo da tabela de variáveis existe pra mostrar o *formato* (`postgres://user:senha@localhost:5432/nome_do_banco`), não um valor que funciona.
- **Todo comando precisa ser copiável e executável como está.** "Rodar o servidor de desenvolvimento" não é comando; `npm run dev` é. Se o comando ainda não existe porque a stack não foi decidida, registre como pendência — ver `deepening.md`.
- **A estrutura de pastas aqui é a fonte da convenção**, e deve bater com o que a Arquitetura descreve. Se as duas divergirem, isso é inconsistência a sinalizar, não a resolver silenciosamente.
- Se o projeto parte de um código já existente (ver `concept/existing-codebase.md`), extraia os comandos reais do que está no repositório — `package.json`, `Makefile`, `README` — em vez de propor comandos que "deveriam" existir.
