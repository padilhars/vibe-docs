# Development Plan — Plano de Desenvolvimento

## Propósito
Transformar o conjunto de requisitos já definido numa sequência lógica de implementação, respeitando dependências reais — não a ordem em que os itens apareceram no PRD ou na conversa.

## Insumos necessários do Blueprint
Funcionalidades, entidades, arquitetura (se já gerada) — dependências técnicas ficam mais claras com a arquitetura definida, então prefira gerar este documento depois dela quando possível.

## Estrutura obrigatória

```markdown
# Plano de Desenvolvimento — [Nome do Projeto]

## Fases

### Fase 1 — Fundação
[o que precisa existir antes de qualquer funcionalidade de negócio: setup de projeto, autenticação básica, modelo de dados inicial]

### Fase 2 — Domínio Central
[entidades e regras de negócio centrais, sem UI ainda se fizer sentido separar]

### Fase 3 — Funcionalidades Core
[FUN-xx do MVP, em ordem de dependência]

### Fase 4 — Integrações
[o que depende de serviço externo]

### Fase 5 — UX e Refinamento
[telas finais, estados de erro, polimento]

### Fase 6 — Testes e Observabilidade
[cobertura de teste dos fluxos críticos, logging]

## Dependências Entre Fases
[o que bloqueia o quê, de forma explícita]

## Marcos
[pontos de verificação intermediários que valem a pena demonstrar]
```

## Regras específicas
- Organize por dependência real, não por ordem de aparição no PRD ou no MVP — uma funcionalidade "importante" que depende de outra "menor" vem depois dela no plano, mesmo que pareça contraintuitivo.
- Se o Domain Model ou a Arquitetura ainda não foram gerados, este plano pode ficar mais genérico nas fases iniciais — registre isso como limitação do documento em vez de inventar decisões técnicas só para completar o plano.
