---
project: "[nome do projeto]"
version: "0.1"
status: "em concept"
idioma_documentacao: "pt-BR"
last_updated: "[data]"
---

# [Nome do Projeto]

## 1. Resumo do Negócio
PENDENTE

## 2. O Problema
PENDENTE

## 3. Objetivos
- OBJ-01: PENDENTE

## 4. Escopo
**Dentro do escopo do projeto:** PENDENTE
**Fora do escopo:** PENDENTE
**Recorte do MVP:** PENDENTE — preenchido quando o MVP for definido

## 5. Atores
- PENDENTE

## 6. Entidades
- ENT-01: PENDENTE

## 7. Estados
PENDENTE

## 8. Funcionalidades
- FUN-01 (OBJ-01): PENDENTE

## 9. Casos de Uso
- UC-01: PENDENTE

## 10. Regras de Negócio
- BR-01: PENDENTE

## 11. Fluxos
PENDENTE

## 12. Permissões
| Ator | Ação | Permitido |
|---|---|---|
| PENDENTE | PENDENTE | PENDENTE |

## 13. Requisitos Técnicos Iniciais
PENDENTE

## 14. Riscos e Pontos de Atenção
PENDENTE

## 15. Estado do Projeto
```
Atores                        ❌ não discutido
Entidades principais           ❌ não discutido
Fluxo principal                ❌ não discutido
Casos de borda                 ❌ não discutido
Permissões                     ❌ não discutido
Requisitos não-funcionais      ❌ não discutido
Riscos / dados sensíveis       ❌ não discutido
Testes e qualidade             ❌ não discutido
```

## 16. Pendências
**Críticas:**
- Tudo — este projeto ainda não passou pelo Concept.

**Menores:**
- Nenhuma ainda.

## 17. Sugestões Futuras (🔵)
Nenhuma ainda.

## 18. Histórico de Decisões
- [data] — Projeto criado a partir deste template.

## 19. Aprofundamento por Área

### Arquitetura
PENDENTE

### UX/UI
PENDENTE

### Dados
PENDENTE

### API
PENDENTE

### Segurança
PENDENTE

### Performance e Escala (NFR)
PENDENTE

### Integrações
PENDENTE

### Testes e Qualidade
PENDENTE

## 20. Princípios Não-Negociáveis
- PRINC-01: PENDENTE

## 21. Definition of Done e Convenções de Trabalho
**Definition of Done:** PENDENTE

**Convenções de código:** PENDENTE

**Convenções de commit e branch:** PENDENTE

## 22. Fase Atual
**Fase atual:** MVP
**Objetivo desta fase:** PENDENTE
**Funcionalidades desta fase:** PENDENTE
**Fases concluídas:** nenhuma ainda
**Próxima fase (provável):** PENDENTE
